package com.develhope.part2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Part2Application {

	public static void main(String[] args) {
		SpringApplication.run(Part2Application.class, args);
	}

}
