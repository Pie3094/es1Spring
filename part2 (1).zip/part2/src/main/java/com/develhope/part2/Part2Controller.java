package com.develhope.part2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class Part2Controller {

    @GetMapping(path = "/nome")
    public String getNome(String nome) {
        return "Ciao, il mio nome è " + nome;
    }

    @PostMapping(path = "/nome")
    public String nomeAlContrario(String nome) {
        StringBuilder stringBuilder = new StringBuilder(nome);
        return "Ciao il mio nome al contrario è " + stringBuilder.reverse();
    }
// localhost:8080/v1/nome?nome=Pietro OK
}
