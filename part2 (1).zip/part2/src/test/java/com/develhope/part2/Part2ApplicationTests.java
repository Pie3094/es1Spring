package com.develhope.part2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Part2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
